/* Lab 5 P3: starter code to complete*/
#include <stdio.h>
#include <string.h>

int main()
{
    char input[256];
    int letterCount[26] = {0}; // Array to store the count of each letter initialized to zeros

    printf("Enter text strings (press Enter on an empty line to exit):\n");

  int a = 0;
    while (1)
    {// stores string read/ max number of characters/ keyboard inputs
        fgets(input, sizeof(input), stdin); // get the input from the user via keyboard

        // Check for an empty line to exit the loop
        if (strlen(input) == 1 && input[0] == '\n')
        {
            break;
        }
        // Your Code should be implemented here
        // Iterate through the characters in the input
        // Check if the character is a letter (A-Z or a-z)
        // Increment the corresponding count in the array

      for(int i = 0; i < 26; i++){
        if ('A' <= input[i] && input[i] <= 'Z'){
          letterCount[input[i] - 'A']++;
        }
        else if ('a' <= input[i] && input[i] <= 'z')
        {
          a = letterCount[i] - 32;
          letterCount[input[i] -'A' - 32]++;
        }
          
        
        }
    }
    // More of your code here to
    // Display the letter counts
    for(int k = 0; k<26;k++){
      printf("%d ", letterCount[k]);
      
    }
  printf("\n");
  printf("A B C D E F G H I J K L M N O P Q R S T U V W X Y Z");

  
    return 0;
}